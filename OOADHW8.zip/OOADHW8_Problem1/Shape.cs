﻿namespace OOADHW8
{
    public abstract class Shape
    {
        public Shape()
        {
        }

        public abstract double perimeter();

        public abstract double area();
    }
}
