﻿namespace OOADHW8
{
    public class Square
    {
        private double a;

        public Square(double a)
        {
            this.a = a;
        }

        public double perimeter()
        {
            return 4 * a;
        }

    }
}
