﻿namespace OOADHW8_Problem2
{
    public abstract class PlaneFigure
    {
        public PlaneFigure()
        {
        }

        protected double size;

        public abstract double perimeter();

        public abstract double area();
    }
}
