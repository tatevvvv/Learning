﻿namespace OOADHW8_Problem2
{
    public abstract class SpaceFigure
    {

        public SpaceFigure()
        {
        }

        protected double size;

        public abstract double surface();

        public abstract double volume();

    }
}
