﻿using OOADHW8_Problem2;

public class Program
{
    public static void Main()
    {
        Client client = new Client();

        //***** aggregating with Acute Angle Factory *****
        client.setFactory(new AcuteAngleFactory());

        //generic behavior
        Console.WriteLine(client.getPlaneFigure(10).perimeter());
        Console.WriteLine(client.getPlaneFigure(10).area());
        Console.WriteLine(client.getSpaceFigure(10).surface());
        Console.WriteLine(client.getSpaceFigure(10).volume());
        Console.WriteLine();

        //***** aggregating with Right Angle Factory *****
        client.setFactory(new RightAngleFactory());

        //generic behavior
        Console.WriteLine(client.getPlaneFigure(10).perimeter());
        Console.WriteLine(client.getPlaneFigure(10).area());
        Console.WriteLine(client.getSpaceFigure(10).surface());
        Console.WriteLine(client.getSpaceFigure(10).volume());
        Console.WriteLine();
    }
}